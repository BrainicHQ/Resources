# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 192.168.10.10 (MySQL 5.7.16-0ubuntu0.16.04.1)
# Database: colectorul
# Generation Time: 2017-08-18 14:11:34 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table counties
# ------------------------------------------------------------

DROP TABLE IF EXISTS `counties`;

CREATE TABLE `counties` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `seo_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `counties` WRITE;
/*!40000 ALTER TABLE `counties` DISABLE KEYS */;

INSERT INTO `counties` (`id`, `name`, `seo_name`)
VALUES
	(53,'BUCURESTI','bucuresti'),
	(41,'Vrancea','vrancea'),
	(40,'Vaslui','vaslui'),
	(39,'Valcea','valcea'),
	(38,'Tulcea','tulcea'),
	(37,'Timis','timis'),
	(36,'Teleorman','teleorman'),
	(35,'Suceava','suceava'),
	(34,'Sibiu','sibiu'),
	(33,'Satu Mare','satu-mare'),
	(32,'Salaj','salaj'),
	(31,'Prahova','prahova'),
	(30,'Olt','olt'),
	(29,'Neamt','neamt'),
	(28,'Mures','mures'),
	(27,'Mehedinti','mehedinti'),
	(26,'Maramures','maramures'),
	(25,'Ilfov','ilfov'),
	(24,'Iasi','iasi'),
	(23,'Ialomita','ialomita'),
	(22,'Hunedoara','hunedoara'),
	(21,'Harghita','harghita'),
	(20,'Gorj','gorj'),
	(19,'Giurgiu','giurgiu'),
	(18,'Galati','galati'),
	(17,'Dolj','dolj'),
	(16,'Dambovita','dambovita'),
	(15,'Covasna','covasna'),
	(14,'Constanta','constanta'),
	(13,'Cluj','cluj'),
	(12,'Caras-Severin','caras-severin'),
	(11,'Calarasi','calarasi'),
	(10,'Buzau','buzau'),
	(9,'Brasov','brasov'),
	(8,'Braila','braila'),
	(7,'Botosani','botosani'),
	(6,'Bistrita-Nasaud','bistrita-nasaud'),
	(5,'Bihor','bihor'),
	(4,'Bacau','bacau'),
	(3,'Arges','arges'),
	(2,'Arad','arad'),
	(1,'Alba','alba');

/*!40000 ALTER TABLE `counties` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
